
window.onload = () => {
    document.getElementById('main').innerHTML = "<p>Bob will have some job's here</p>"
}

